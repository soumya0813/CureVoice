import { N, _ } from "../chunks/2.BAR5dNFu.js";
export {
  N as component,
  _ as universal
};
